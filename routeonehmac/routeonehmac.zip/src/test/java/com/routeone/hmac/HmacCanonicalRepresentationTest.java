package com.routeone.hmac;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.net.URI;

import com.routeone.api.HmacAuthenticationGeneratorRequest;
import com.routeone.api.RouteOneHeaders;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;
import com.google.common.net.HttpHeaders;

public class HmacCanonicalRepresentationTest {
    public static final String API_SHARED_SECRET = "a1b2c3d4e5f6g7h8i9j0";
    private static final String CONTENT_TYPE_JSON = "application/json";
    private static final String R1_DEALER_ID = "D12345";
    private static final String CANONICAL_DATE = "thu, 04 feb 2016 16:29:02 gmt";
    private static final String USER_ID = "JOHNDOE";
    private static final String CONTENT_MD5 = "c5XhceQSbvLvn9FkWoCcog==";
    private static final String HTTP_REQUEST_METHOD = "POST";
    private static final String ROUTEONE_URL = "http://localhost:8074/customer-quote/finance";

    private static final String CANONICAL_REPRESENTATION = new StringBuilder().append(HTTP_REQUEST_METHOD).append("\n")
            .append(CONTENT_MD5.toLowerCase()).append("\n")
            .append(CONTENT_TYPE_JSON).append("\n")
            .append(CANONICAL_DATE).append("\n")
            .append("x-routeone-act-as-dealership:").append(R1_DEALER_ID).append("\n")
            .append("x-routeone-date:").append(CANONICAL_DATE).append("\n")
            .append("x-routeone-user-id:").append(USER_ID).append("\n")
            .append("/customer-quote/finance").append("\n").toString();

    private static HmacAuthenticationGeneratorRequest request;

    @BeforeClass
    public static void setup() {
        ListMultimap<String, String> headers = ArrayListMultimap.create();

        headers.put(RouteOneHeaders.DEALER_ID, R1_DEALER_ID);
        headers.put(RouteOneHeaders.X_ROUTEONE_DATE, CANONICAL_DATE);
        headers.put(RouteOneHeaders.USER_ID, USER_ID);
        headers.put(HttpHeaders.CONTENT_MD5, CONTENT_MD5);
        headers.put(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_JSON);

        request = new HmacAuthenticationGeneratorRequest.Builder(
                API_SHARED_SECRET).withHttpRequestMethod(HTTP_REQUEST_METHOD).withRequestUri(URI.create(ROUTEONE_URL)).withRequestHeaders(headers).create();
    }

    @Test
    public void validHmacCanonicalRepresentationFromRequest() {
        String canonicalRepresentation = new HmacCanonicalRepresentation(request).toString();

        assertThat(canonicalRepresentation, is(CANONICAL_REPRESENTATION));
    }

    @Test
    public void validHmacCanonicalRepresentationFromParameters() {

        HmacAuthenticationGeneratorRequest request = new HmacAuthenticationGeneratorRequest.Builder(
                API_SHARED_SECRET).withHttpRequestMethod(HTTP_REQUEST_METHOD)
                                  .withRequestUri(URI.create(ROUTEONE_URL))
                                  .withRteOneDealerId(R1_DEALER_ID)
                                  .withRteOneDate(CANONICAL_DATE)
                                  .withUserId(USER_ID)
                                  .withContentMd5(CONTENT_MD5)
                                  .withContentType(CONTENT_TYPE_JSON)
                                  .create();

        String canonicalRepresentation = new HmacCanonicalRepresentation(request).toString();

        assertThat(canonicalRepresentation, is(CANONICAL_REPRESENTATION));
    }
}