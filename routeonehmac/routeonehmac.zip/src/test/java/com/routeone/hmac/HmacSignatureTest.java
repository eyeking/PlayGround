package com.routeone.hmac;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import com.routeone.fault.HmacSignatureGenerationException;
import org.junit.Test;

public class HmacSignatureTest {
    @Test
    public void testCompute() throws HmacSignatureGenerationException {
        String sharedSecret="1qphOnc2yI3PKTCeJfTYEGJIRnp4l0Lmbjr517rp";
        String algorithm="HmacSHA256";
        String canonicalRepresentation ="POST" + "\n" +
                "8f0974da4474adbdaabcb7c3eea15d88" + "\n" +
                "application/json" + "\n" +
                "Wed, 26 Jun 2013 17:11:50 GMT" + "\n" +
                "x-routeone-act-as-dealership:D12345" + "\n" +
                "/api/deals\n";
        HmacSignature hmacSignature = new HmacSignature(sharedSecret, algorithm, canonicalRepresentation);
        assertEquals("Correct Signature returned", "sLCfYGKXp6i7WkmUlCyudSrEAWmmWENKqOqj0E+zvzg=",hmacSignature.compute());

    }

}