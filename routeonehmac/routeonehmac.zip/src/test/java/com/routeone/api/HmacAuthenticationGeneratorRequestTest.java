package com.routeone.api;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;

import java.net.URI;

import org.junit.Test;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;
import com.google.common.net.HttpHeaders;

public class HmacAuthenticationGeneratorRequestTest {
    public static final String API_SHARED_SECRET = "a1b2c3d4e5f6g7h8i9j0";
    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String R1_DEALER_ID = "D12345";
    public static final String PARTNER_DEALER_ID = "40506";
    public static final String CANONICAL_DATE = "thu, 04 feb 2016 16:29:02 gmt";
    public static final String USER_ID = "JOHNDOE";
    public static final String CONTENT_MD5 = "c5XhceQSbvLvn9FkWoCcog==";
    public static final String HTTP_REQUEST_METHOD = "POST";
    public static final String ROUTEONE_URL = "http://localhost:8074/customer-quote/finance";

    public static final HmacAuthenticationGeneratorRequest HMAC_GENERATOR_REQUEST_FROM_HEADERS;
    public static final HmacAuthenticationGeneratorRequest HMAC_GENERATOR_REQUEST_FROM_PARAMS;

    static {
        ListMultimap<String, String> headers = ArrayListMultimap.create();

        headers.put(RouteOneHeaders.DEALER_ID, R1_DEALER_ID);
        headers.put(RouteOneHeaders.PARTNER_DEALER_ID, PARTNER_DEALER_ID);
        headers.put(RouteOneHeaders.X_ROUTEONE_DATE, CANONICAL_DATE);
        headers.put(RouteOneHeaders.USER_ID, USER_ID);
        headers.put(HttpHeaders.CONTENT_MD5, CONTENT_MD5);
        headers.put(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_JSON);

        HMAC_GENERATOR_REQUEST_FROM_HEADERS = new HmacAuthenticationGeneratorRequest.Builder(
                API_SHARED_SECRET).withHttpRequestMethod(HTTP_REQUEST_METHOD).withRequestUri(URI.create(ROUTEONE_URL)).withRequestHeaders(headers).create();

        HMAC_GENERATOR_REQUEST_FROM_PARAMS = new HmacAuthenticationGeneratorRequest.Builder(
                API_SHARED_SECRET).withHttpRequestMethod(HTTP_REQUEST_METHOD)
                                  .withRequestUri(URI.create(ROUTEONE_URL))
                                  .withRteOneDealerId(R1_DEALER_ID)
                                  .withPartnerDealerId(PARTNER_DEALER_ID)
                                  .withRteOneDate(CANONICAL_DATE)
                                  .withUserId(USER_ID)
                                  .withContentMd5(CONTENT_MD5)
                                  .withContentType(CONTENT_TYPE_JSON)
                                  .create();
    }

    @Test
    public void validRequestFromBuilder() {
        URI requestURI = HMAC_GENERATOR_REQUEST_FROM_HEADERS.getRequestUri();

        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getSecretKey(), is(API_SHARED_SECRET));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getContentMd5(), is(CONTENT_MD5));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getContentType(), is(CONTENT_TYPE_JSON));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getHttpRequestMethod(), is(HTTP_REQUEST_METHOD));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getPartnerDealerId(), is(PARTNER_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getUserId(), is(USER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getRteOneDealerId(), is(R1_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_HEADERS.getRteOneDate(), is(CANONICAL_DATE));
        assertThat(requestURI.getScheme() + "://" + requestURI.getHost() + ":" + requestURI.getPort() + requestURI.getPath(),
                   is(ROUTEONE_URL));
    }

    @Test
    public void validRequestFromParameters() {
        URI requestURI = HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestUri();

        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getSecretKey(), is(API_SHARED_SECRET));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getContentMd5(), is(CONTENT_MD5));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getContentType(), is(CONTENT_TYPE_JSON));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getHttpRequestMethod(), is(HTTP_REQUEST_METHOD));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getPartnerDealerId(), is(PARTNER_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getUserId(), is(USER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRteOneDealerId(), is(R1_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRteOneDate(), is(CANONICAL_DATE));
        assertThat(requestURI.getScheme() + "://" + requestURI.getHost() + ":" + requestURI.getPort() + requestURI.getPath(),
                   is(ROUTEONE_URL));

        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(RouteOneHeaders.DEALER_ID).get(0), is(R1_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(RouteOneHeaders.PARTNER_DEALER_ID).get(0), is(PARTNER_DEALER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(RouteOneHeaders.X_ROUTEONE_DATE).get(0), is(CANONICAL_DATE));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(RouteOneHeaders.USER_ID).get(0), is(USER_ID));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(HttpHeaders.CONTENT_MD5).get(0), is(CONTENT_MD5));
        assertThat(HMAC_GENERATOR_REQUEST_FROM_PARAMS.getRequestHeaders().get(HttpHeaders.CONTENT_TYPE).get(0), is(CONTENT_TYPE_JSON));
    }
}